package com.bardaval.recycylerviewexample

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.LayoutManager

class RecyclerViewActivity : AppCompatActivity() {

    lateinit var arrayList: ArrayList<DataModel>
    lateinit var recyclerView: RecyclerView
    var recyclerAdapter: RecyclerAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recyler_view)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        arrayList = ArrayList<DataModel>()
        arrayList.add(DataModel("Samsung Galaxy S21", "10.0"))
        arrayList.add(DataModel("iPhone 12", "11.0"))
        arrayList.add(DataModel("Google Pixel 5", "12.0"))
        arrayList.add(DataModel("OnePlus 9", "13.0"))
        arrayList.add(DataModel("Xiaomi Mi 11", "14.0"))
        arrayList.add(DataModel("Oppo Find X3", "15.0"))
        arrayList.add(DataModel("Vivo X60", "16.0"))

        recyclerView = findViewById(R.id.recyclerview)
        recyclerView.adapter = RecyclerAdapter(this, arrayList)
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerView.setHasFixedSize(true)
    }
}
