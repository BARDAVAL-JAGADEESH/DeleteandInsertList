package com.bardaval.recycylerviewexample

class DataModel(val versionName: String, val version: String) {

}
