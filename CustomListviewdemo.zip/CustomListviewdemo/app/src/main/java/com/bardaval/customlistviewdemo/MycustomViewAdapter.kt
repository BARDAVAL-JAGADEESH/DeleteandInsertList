package com.bardaval.customlistviewdemo

import android.content.Context
import android.icu.text.CaseMap.Title
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import androidx.leanback.widget.TitleView

class MycustomViewAdapter(var mCtx:Context,var resouces:Int,var items:MutableList<ModelDemo>):ArrayAdapter<ModelDemo>(mCtx,resouces,items)
{


    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {

        val layoutInflater:LayoutInflater=LayoutInflater.from(mCtx)
        val view:View=layoutInflater.inflate(resouces,null)
        val imageView:ImageView=view.findViewById(R.id.img1)

        val titleText:TitleView=view.findViewById<>()
    }
}