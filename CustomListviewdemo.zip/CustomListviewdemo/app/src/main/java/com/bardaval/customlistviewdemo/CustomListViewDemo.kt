package com.bardaval.customlistviewdemo

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class CustomListViewDemo: AppCompatActivity() {

        lateinit var et1:EditText
        lateinit var et2:EditText
        lateinit var add:Button
        @SuppressLint("MissingInflateId")
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_custom_list_demo)
            var listView=findViewById<ListView>(R.id.listView)
            var list= mutableListOf<ModelDemo>()
            et1=findViewById(R.id.et1)
            et2=findViewById(R.id.et2)
            add=findViewById(R.id.add)
            var ad= MycustomViewAdapter(
                this,R.layout.mycustomlookfile,list)
            listView.adapter=add.setOnClickListener {it:View!
                list.add(ModelDemo(et1.text.toString(),et2.text.toString(),R.drawable.ic_launcher_background))
                ad.notifyDataSetChanged()


            }
            listView.setOnItemClickListener{ parent}
        }
    }