package com.bardaval.customlistviewdemo

import android.icu.text.CaseMap.Title

class ModelDemo(val title: String,val subTitle,val img:Int) {
}